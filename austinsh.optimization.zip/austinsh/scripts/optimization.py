from models.Buses import Buses
from models.Loads import Loads
from models.Generators import Generators

def optimize_linear(buses, branches, slack, size):
    i_linear = []
    j_linear = []
    linear_value = []
    for ele in buses:
        ir_infeasible = ele.node_infeasible_r
        ii_infeasible = ele.node_infeasible_i
        vr = ele.node_Vr
        vi = ele.node_Vi
        lr = ele.node_lambda_r
        li = ele.node_lambda_i
        y_stamps = [
            [ir_infeasible, ir_infeasible, 2], [ir_infeasible, lr, 1]
            [ii_infeasible, ii_infeasible, 2], [ir_infeasible, li, 1]
            [vr, ir_infeasible, 1],
            [vi, ii_infeasible, 1],
        ]
        for indicies in y_stamps:
            i, j, value = indicies
            i_linear.append(i)
            j_linear.append(j)
            linear_value.append(value)
    for ele in branches:
        lambdar_i = Buses.bus_key_[str(ele.from_bus) + "_lambda_r"]
        lambdai_i = Buses.bus_key_[str(ele.from_bus) + "_lambda_i"]
        lambdar_j = Buses.bus_key_[str(ele.to_bus) + "_lambda_r"]
        lambdai_j = Buses.bus_key_[str(ele.to_bus) + "_lambda_i"]
        y_stamps = [
            [lambdar_i, lambdar_i, ele.conductance], [lambdar_i, lambdar_j, -ele.conductance], 
            [lambdar_i, lambdai_i, -ele.se_coeff], [lambdar_i, lambdai_j, ele.se_coeff],
            [lambdar_j, lambdar_j, ele.conductance], [lambdar_j, lambdar_i, -ele.conductance],
            [lambdar_j, lambdai_j, -ele.se_coeff], [lambdar_j, lambdai_i, ele.se_coeff],
            [lambdai_i, lambdai_i, ele.conductance], [lambdai_i, lambdai_j, -ele.conductance],
            [lambdai_i, lambdar_i, ele.se_coeff], [lambdai_i, lambdar_j, -ele.se_coeff],
            [lambdai_j, lambdai_j, ele.condctance], [lambdai_j, lambdai_i, -ele.conductance],
            [lambdai_j, lambdar_j, ele.se_coeff], [lambdai_j, lambdai_i, -ele.se_coeff],
            [lambdar_i, lambdai_i, -ele.sh_coeff], [lambdai_i, lambdar_i, ele.sh_coeff],
            [lambdar_j, lambdai_j, -ele.sh_coeff], [lambdai_j, lambdar_j, ele.sh_coeff]
        ]
        for indicies in y_stamps:
            i, j, value = indicies
            i_linear.append(i)
            j_linear.append(j)
            linear_value.append(value)
    for ele in slack:
        lambdar = Buses.bus_key_[str(ele.bus) + "_lambda_r"]
        lambdai = Buses.bus_key_[str(ele.bus) + "_lambda_i"]
        lambdar_ir = ele.node_lambdar_ir
        lambdai_ii = ele.node_lambdai_ii
        y_stamps = [
            [lambdar_ir, lambdar, 1], [lambdai_ii, lambdai, 1],
            [lambdar, lambdar_ir, 1], [lambdai, lambdai_ii, 1]
        ]
        for indicies in y_stamps:
            i, j, value = indicies
            i_linear.append(i)
            j_linear.append(j)
            linear_value.append(value)

def optimize_nonlinear(generators, loads, pre_sol, size):
    i_nonlinear = []
    j_nonlinear = []
    nonlinear_value = []
    j_row = []
    j_column = []
    j_value = []
    for elem in loads:
        lr = Buses.bus_key_[str(elem.bus) + "_lambda_r"]
        li = Buses.bus_key_[str(elem.bus) + "_lambda_i"]
        vr = Buses.bus_key_[str(elem.bus) + "_vr"]
        vi = Buses.bus_key_[str(elem.bus) + "_vi"]
        IR_by_VR, IR_by_VI, II_by_VR, II_by_VI = Loads.pq_derivative(elem, pre_sol)
        AR_by_VR, AR_by_VI, AI_by_VR, AI_by_VI = Loads.optimize_derivative(elem, pre_sol)
        y_stamps = [
            [lr, vr, AR_by_VR], [lr, vi, AR_by_VI], [lr, lr, IR_by_VR], [lr, li, II_by_VR],
            [li, vr, AI_by_VR], [li, vi, AI_by_VI], [li, li, II_by_VI], [li, lr, IR_by_VI]
        ]
        j_LR, j_LI = Loads.optimize_history(
            elem, pre_sol, IR_by_VR, IR_by_VI, II_by_VR, II_by_VI,
            AR_by_VR, AR_by_VI, AI_by_VR, AI_by_VI
        )
        j_stamps = [
            [lr, 0, j_LR],
            [li, 0, j_LI]
        ]
        for indicies in y_stamps:
            i, j, value = indicies
            i_nonlinear.append(i)
            j_nonlinear.append(j)
            nonlinear_value.append(value)
        for index in j_stamps:
            i, j, value = index
            j_row.append(i)
            j_column.append(j)
            j_value.append(value)
    for elem in generators:
        lr = Buses.bus_key_[str(elem.bus) + "_lambda_r"]
        li = Buses.bus_key_[str(elem.bus) + "_lambda_i"]
        lq = Buses.bus_key_[str(elem.bus) + "_lambda_q"]
        vr = Buses.bus_key_[str(elem.bus) + "_vr"]
        vi = Buses.bus_key_[str(elem.bus) + "_vi"]
        q = Buses.bus_key_[str(elem.bus) + "_q"]
