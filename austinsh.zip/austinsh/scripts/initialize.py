
def initialize(Initial_state, buses, generators, slacks):
       
    bus_counter = 0
    count_pq_and_slack = 0
    count_pv = 0
    count_slack_pq = 0

    for ele in Initial_state:
        bus_type = buses[bus_counter].Type
        if bus_type == 1 or bus_type == 3:
            count_pq_and_slack += 1
            if count_pq_and_slack % 2 == 1:
                Initial_state[ele - 1] = buses[bus_counter].node_Vr
                Initial_state[ele] = buses[bus_counter].node_Vi
                bus_counter += 1
        elif bus_type == 2:
            count_pv += 1
            if count_pv % 3 == 2:
                Initial_state[ele - 2] = buses[bus_counter].node_Vr
                Initial_state[ele - 1] = buses[bus_counter].node_Vi
                for ele in generators:
                    # Doesn't deal with multiple slacks...need to think about this more
                    if generators[ele].bus == bus_counter:
                        qinit = generators[ele].qinit
                Initial_state[ele] = qinit
                bus_counter += 1
        if bus_counter == max(buses):
            count_slack_pq += 1
            if count_slack_pq % 2 == 1:
                Initial_state[ele - 1] = slacks[count_slack_pq -2].pinit
                Initial_state[ele] = slacks[count_slack_pq -2].qinit

    return Initial_state