class global_vars:
    """Global variables to use throughout the solver.

    """
    def __init__(self):
        pass
    MVAbase=100
    f=60

